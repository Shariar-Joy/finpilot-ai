﻿# FinPilot AI submission package

Source and setup: https://github.com/Shariar-Joy/finpilot-ai

## Included files

- pdf/01-technical-paper.pdf: architecture, algorithms, security and measured evaluation.
- pdf/02-security-self-assessment.pdf: permission tiers, controls, verification and residual risks.
- pdf/03-execution-evidence.pdf: actual sandbox evidence and reproduction instructions.
- pdf/04-submission-checklist.pdf: two-member blank identity fields and requirements checklist.
- FinPilot_AI_Overleaf.zip: upload this ZIP to Overleaf; select main.tex and compile with pdfLaTeX.
- evidence/demo.webm: actual captioned application recording; no presentation deck is included.
- evidence/: recording metadata, real synthetic audit events, test summary, benchmark and screenshots.
- gamma-presentation-prompt.md: prompt for creating the presentation separately.
- competition-requirements.md and review-report.md: requirements mapping and completed source review.
- SHA256SUMS.txt: checksums for package contents.

## Before submitting

Fill both members identity, institution and contact fields in the LaTeX sources; review eligibility, claims, independence/IP terms and signatures. The blank fields are not signed declarations. Recompile and inspect all four documents after editing.

This package uses synthetic financial data. Local PostgreSQL and live paid-model execution were not exercised; consult the repository CI outcome for remote database verification. No hosted application or security certification is claimed.

The supplied rules state a deadline of 20 October 2026, 23:59 Beijing time (21:59 Bangladesh). Check later organizer notices and the accepted upload format before submission.
